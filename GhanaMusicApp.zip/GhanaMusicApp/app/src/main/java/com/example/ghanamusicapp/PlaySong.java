package com.example.ghanamusicapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PlaySong extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_song);
        // Capture the layout's TextView and set the string as its text
        ImageView playSong = (ImageView) findViewById(R.id.playSong_imageview);
        playSong.setImageResource(R.drawable.ps1);
    }
}
