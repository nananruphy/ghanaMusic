package com.example.ghanamusicapp;

public class Music {
    /** Artist name */
    private String myartist;

    /** Album title and year */
    private String myalbum;

    /**
     * Create a new Music object.
     */
    public Music(String artist, String album) {
        myartist = artist;
        myalbum = album;
    }

    /**
     * Get the artist for the music.
     */
    public String getArtist() {
        return myartist;
    }

    /**
     * Get the album for the music.
     */
    public String getAlbum() {
        return myalbum;
    }


}
