package com.example.ghanamusicapp;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class Afro extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        ArrayList<Music> music= new ArrayList<Music>();
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));
        music.add(new Music("Kuami Eugene", "Wish Me Well     2018"));
        music.add(new Music("Kuami Eugene", "Open Gate     2020"));
        music.add(new Music("Kuami Eugene", "Dollar On You    2021"));



        MusicAdapter adapter = new MusicAdapter(this, music);
        ListView listView = (ListView) findViewById(R.id.music_list);
        listView.setAdapter(adapter);
    }
}
